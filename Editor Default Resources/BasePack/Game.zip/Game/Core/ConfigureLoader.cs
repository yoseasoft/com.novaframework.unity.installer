// using Luban;
using System;
using GameEngine;
using UnityEngine;
using Cysharp.Threading.Tasks;
using System.Collections.Generic;

using GooAsset;

namespace Game
{
    /// <summary>
    /// ConfigureLoader会扫描所有的有ConfigAttribute标签的配置, 加载进来
    /// </summary>
    public static class ConfigureLoader
    {
        public static async UniTask Load()
        {
            // 加载数据表
            await LoadAsync();
        }

        public static void Unload()
        {
        }

        public static async UniTask Reload()
        {
            // 重新导入配置数据
            await ReloadAsync();
        }

        /// <summary>
        /// 异步加载所有配置
        /// </summary>
        private static async UniTask LoadAsync()
        {
            await UniTask.WaitForSeconds(0.1f);
        }

        /// <summary>
        /// 重载配置表
        /// </summary>
        private static async UniTask ReloadAsync()
        {
            await LoadAsync();

            // 重载本地化文字
            // Localization.Reload();
        }

        
    }
}
