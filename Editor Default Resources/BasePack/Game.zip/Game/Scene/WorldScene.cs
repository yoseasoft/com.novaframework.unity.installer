/// <summary>
/// 2025-12-20 Game Framework Code By Hurley
/// </summary>

namespace Game
{
    /// <summary>
    /// 世界场景
    /// </summary>
    [GSceneClass("World")]
    public sealed class WorldScene : GScene
    {
    }
}
