/// <summary>
/// 2025-12-10 Game Framework Code By Hurley
/// </summary>


using UnityObject = UnityEngine.Object;
using GameObject = UnityEngine.GameObject;

namespace Game
{
    /// <summary>
    /// Logo场景
    /// </summary>
    static class LogoSceneSystem
    {
        [OnAwake]
        static void Awake(this LogoScene self)
        {
        }

        [OnStart]
        static void Start(this LogoScene self)
        {
            UnityEngine.Debug.Log("遊戲正常啟動！！！！！！");
            // 加载并实例化 HelloWorld 对象
            LoadHelloWorldObject(self);
            
        }

        static async void LoadHelloWorldObject(LogoScene scene)
        {
            try
            {
                // 使用Nova Engine的API加载prefab
                // prefab路径应该是相对于Assets/_Resources的路径
                string prefabPath = "Assets/_Resources/GUI/helloWorld.prefab";
                
                var asset = await NE.ResourceHandler.LoadAssetAsync<GameObject>(prefabPath);
                
                if (asset != null)
                {
                    // 成功加载了prefab，现在实例化它
                    GameObject helloWorldObj = UnityObject.Instantiate(asset);
                    
                    UnityEngine.Debug.Log("HelloWorld prefab loaded and instantiated successfully!");
                }
                else
                {
                    UnityEngine.Debug.LogWarning("Failed to load HelloWorld prefab from " + prefabPath);
                }
            }
            catch (System.Exception ex)
            {
                UnityEngine.Debug.LogError($"Error loading HelloWorld object: {ex.Message}");
            }
        }
        
    }
}